import { useEffect, useState, useCallback } from "react";

import {
  LogOut,
  Briefcase,
  FileCheck,
  Send,
  User,
  ExternalLink,
  FolderKanban,
} from "lucide-react";

import "../../styles/developer.css";

import ExcwaLogo from "../../components/common/ExcwaLogo";
import OpportunitiesTab from "../../components/developer/OpportunitiesTab";

import { useDeveloper } from "../../hooks/useDeveloper";

import {
  getMyApplications,
  getMyCurrentAssignment,
} from "../../services/developerService";

import {
  submitProject,
} from "../../services/developer/developerSubmissionService";

/* =========================================================
   STATUS COLORS
========================================================= */

const STATUS_COLORS = {
  approved: {
    color: "#69e5b7",
    bg: "rgba(105,229,183,.08)",
    border: "rgba(105,229,183,.2)",
  },

  selected: {
    color: "#69e5b7",
    bg: "rgba(105,229,183,.08)",
    border: "rgba(105,229,183,.2)",
  },

  assigned: {
    color: "#69e5b7",
    bg: "rgba(105,229,183,.08)",
    border: "rgba(105,229,183,.2)",
  },

  in_progress: {
    color: "#62e2ff",
    bg: "rgba(98,226,255,.08)",
    border: "rgba(98,226,255,.2)",
  },

  submitted: {
    color: "#62e2ff",
    bg: "rgba(98,226,255,.08)",
    border: "rgba(98,226,255,.2)",
  },

  under_review: {
    color: "#a98cff",
    bg: "rgba(169,140,255,.08)",
    border: "rgba(169,140,255,.2)",
  },

  changes_requested: {
    color: "#ffca70",
    bg: "rgba(255,202,112,.08)",
    border: "rgba(255,202,112,.2)",
  },

  completed: {
    color: "#69e5b7",
    bg: "rgba(105,229,183,.08)",
    border: "rgba(105,229,183,.2)",
  },

  rejected: {
    color: "#ff7373",
    bg: "rgba(255,115,115,.08)",
    border: "rgba(255,115,115,.2)",
  },

  pending: {
    color: "#ffca70",
    bg: "rgba(255,202,112,.08)",
    border: "rgba(255,202,112,.2)",
  },
};

/* =========================================================
   STATUS BADGE
========================================================= */

function StatusBadge({ status }) {
  const normalizedStatus =
    status?.toString().toLowerCase() || "pending";

  const style =
    STATUS_COLORS[normalizedStatus] ||
    STATUS_COLORS.pending;

  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "6px 11px",
        borderRadius: 999,
        fontSize: 10,
        fontWeight: 600,
        color: style.color,
        background: style.bg,
        border: `1px solid ${style.border}`,
        textTransform: "capitalize",
        whiteSpace: "nowrap",
      }}
    >
      <span
        style={{
          width: 6,
          height: 6,
          borderRadius: "50%",
          background: style.color,
        }}
      />

      {normalizedStatus.replace(/_/g, " ")}
    </span>
  );
}

/* =========================================================
   HELPER
========================================================= */

function getOpportunity(assignment) {
  if (!assignment) return null;

  return (
    assignment.opportunities ||
    assignment.opportunity ||
    null
  );
}

function getAssignmentId(assignment) {
  return (
    assignment?.id ||
    assignment?.assignment_id ||
    null
  );
}

/* =========================================================
   CURRENT PROJECT
========================================================= */

function CurrentProjectTab({ assignment }) {
  if (!assignment) {
    return (
      <div className="dev-tab-empty">
        <FolderKanban
          size={34}
          style={{
            opacity: 0.3,
            marginBottom: 12,
          }}
        />

        <p>No active project.</p>

        <span>
          Browse opportunities to find your next project.
        </span>
      </div>
    );
  }

  const project = getOpportunity(assignment);

  return (
    <div className="dev-current-project">

      <div className="dev-project-header">
        <div>
          <span className="dev-opp-category">
            {project?.category || "Project"}
          </span>

          <h2>
            {project?.title || "Untitled Project"}
          </h2>

          <p>
            Project ID:{" "}
            {project?.id || assignment.opportunity_id || "—"}
          </p>
        </div>

        <StatusBadge
          status={
            assignment.status || "in_progress"
          }
        />
      </div>

      <div className="dev-project-section">
        <h3>Project Requirement</h3>

        <p>
          {project?.description ||
            "No description provided."}
        </p>
      </div>

      <div className="dev-project-grid">

        <div className="dev-project-info">
          <span>Project Type</span>

          <strong>
            {project?.project_type || "—"}
          </strong>
        </div>

        <div className="dev-project-info">
          <span>Deadline</span>

          <strong>
            {project?.deadline
              ? new Date(
                  project.deadline
                ).toLocaleDateString("en-IN")
              : "—"}
          </strong>
        </div>

        <div className="dev-project-info">
          <span>Developer Payout</span>

          <strong>
            {project?.freelancer_payout != null
              ? `₹${Number(
                  project.freelancer_payout
                ).toLocaleString("en-IN")}`
              : "—"}
          </strong>
        </div>

        <div className="dev-project-info">
          <span>Assigned</span>

          <strong>
            {assignment.assigned_at
              ? new Date(
                  assignment.assigned_at
                ).toLocaleDateString("en-IN")
              : "—"}
          </strong>
        </div>

      </div>

      {Array.isArray(project?.tech_stack) &&
        project.tech_stack.length > 0 && (
          <div className="dev-project-section">
            <h3>Technology Stack</h3>

            <div className="dev-opp-tags">
              {project.tech_stack.map(
                (tech, index) => (
                  <span
                    key={`${tech}-${index}`}
                    className="dev-tag"
                  >
                    {tech}
                  </span>
                )
              )}
            </div>
          </div>
        )}

      {Array.isArray(project?.required_skills) &&
        project.required_skills.length > 0 && (
          <div className="dev-project-section">
            <h3>Required Skills</h3>

            <div className="dev-opp-tags">
              {project.required_skills.map(
                (skill, index) => (
                  <span
                    key={`${skill}-${index}`}
                    className="dev-tag"
                  >
                    {skill}
                  </span>
                )
              )}
            </div>
          </div>
        )}

      {project?.deliverables && (
        <div className="dev-project-section">
          <h3>Deliverables</h3>

          <p>{project.deliverables}</p>
        </div>
      )}
    </div>
  );
}

/* =========================================================
   SUBMIT WORK
========================================================= */

function SubmitWorkTab({
  assignment,
  onSubmitted,
}) {
  const [githubUrl, setGithubUrl] = useState("");
  const [notes, setNotes] = useState("");

  const [submitting, setSubmitting] =
    useState(false);

  const [message, setMessage] =
    useState("");

  const [error, setError] =
    useState("");

  const submission =
    assignment?.project_submissions?.[0] ||
    assignment?.submission ||
    null;

  const submissionStatus =
    submission?.status
      ?.toString()
      .toLowerCase() || null;

  const assignmentStatus =
    assignment?.status
      ?.toString()
      .toLowerCase() || null;

  const assignmentId =
    getAssignmentId(assignment);

  const canResubmit =
    submissionStatus === "changes_requested";

  const submissionLocked =
    submissionStatus === "submitted" ||
    submissionStatus === "under_review";

  const projectCompleted =
    assignmentStatus === "completed" ||
    submissionStatus === "completed";

  async function handleSubmit() {
    setError("");
    setMessage("");

    const cleanGithubUrl =
      githubUrl.trim();

    const cleanNotes =
      notes.trim();

    if (!cleanGithubUrl) {
      setError(
        "GitHub repository URL is required."
      );
      return;
    }

    if (!assignmentId) {
      setError(
        "Assignment ID is missing."
      );

      console.error(
        "Assignment object:",
        assignment
      );

      return;
    }

    if (
      !cleanGithubUrl.startsWith(
        "http://"
      ) &&
      !cleanGithubUrl.startsWith(
        "https://"
      )
    ) {
      setError(
        "Please enter a valid GitHub repository URL."
      );
      return;
    }

    setSubmitting(true);

    try {
      await submitProject({
        assignmentId,
        githubUrl: cleanGithubUrl,
        submissionNotes:
          cleanNotes || null,
      });

      setMessage(
        "Your work has been submitted successfully. It is now waiting for reviewer approval."
      );

      setGithubUrl("");
      setNotes("");

      if (onSubmitted) {
        await onSubmitted();
      }
    } catch (err) {
      console.error(
        "Project submission failed:",
        err
      );

      setError(
        err?.message ||
          "Unable to submit your work."
      );
    } finally {
      setSubmitting(false);
    }
  }

  if (!assignment) {
    return (
      <div className="dev-tab-empty">
        <Send
          size={34}
          style={{
            opacity: 0.3,
            marginBottom: 12,
          }}
        />

        <p>No active project.</p>

        <span>
          You can submit work once a project is assigned.
        </span>
      </div>
    );
  }

  if (projectCompleted) {
    return (
      <div className="dev-tab-empty">
        <FileCheck
          size={34}
          style={{
            opacity: 0.3,
            marginBottom: 12,
          }}
        />

        <p>Project completed.</p>

        <span>
          This project has been completed by the reviewer.
        </span>
      </div>
    );
  }

  const project =
    getOpportunity(assignment);

  return (
    <div className="dev-auth-card dev-submit-card">

      <div className="dev-submit-header">
        <div>
          <span className="dev-opp-category">
            Current Project
          </span>

          <h2>
            {project?.title || "Project"}
          </h2>
        </div>

        <StatusBadge
          status={
            submissionStatus ||
            assignmentStatus ||
            "in_progress"
          }
        />
      </div>

      {canResubmit && (
        <div
          style={{
            marginBottom: 18,
            padding: 14,
            borderRadius: 10,
            background:
              "rgba(255,202,112,.08)",
            border:
              "1px solid rgba(255,202,112,.2)",
          }}
        >
          <strong
            style={{
              color: "#ffca70",
            }}
          >
            Changes requested
          </strong>

          {submission?.review_message && (
            <p style={{ marginTop: 8 }}>
              {submission.review_message}
            </p>
          )}

          <p style={{ marginTop: 8 }}>
            Update your project and submit it again.
          </p>
        </div>
      )}

      {submissionStatus === "submitted" && (
        <div
          style={{
            marginBottom: 18,
            padding: 14,
            borderRadius: 10,
            background:
              "rgba(98,226,255,.08)",
            border:
              "1px solid rgba(98,226,255,.2)",
          }}
        >
          <strong
            style={{
              color: "#62e2ff",
            }}
          >
            Work submitted
          </strong>

          <p>
            Your submission is waiting for reviewer approval.
          </p>
        </div>
      )}

      {submissionStatus === "under_review" && (
        <div
          style={{
            marginBottom: 18,
            padding: 14,
            borderRadius: 10,
            background:
              "rgba(169,140,255,.08)",
            border:
              "1px solid rgba(169,140,255,.2)",
          }}
        >
          <strong
            style={{
              color: "#a98cff",
            }}
          >
            Under review
          </strong>

          <p>
            A reviewer is currently reviewing your submission.
          </p>
        </div>
      )}

      <div className="field">
        <label>
          GitHub Repository URL <em>*</em>
        </label>

        <input
          type="url"
          placeholder="https://github.com/username/project"
          value={githubUrl}
          onChange={(event) =>
            setGithubUrl(event.target.value)
          }
          disabled={
            submitting ||
            submissionLocked
          }
        />
      </div>

      <div
        className="field"
        style={{
          marginTop: 16,
        }}
      >
        <label>
          Submission Notes{" "}
          <em
            style={{
              color: "#5e6a7b",
              fontStyle: "normal",
            }}
          >
            optional
          </em>
        </label>

        <textarea
          rows={5}
          placeholder="Add setup instructions or any important notes..."
          value={notes}
          onChange={(event) =>
            setNotes(event.target.value)
          }
          disabled={
            submitting ||
            submissionLocked
          }
        />
      </div>

      {error && (
        <p className="error">
          {error}
        </p>
      )}

      {message && (
        <p
          style={{
            color: "#69e5b7",
            fontSize: 12,
          }}
        >
          {message}
        </p>
      )}

      <button
        type="button"
        className="primary-btn form-submit"
        onClick={handleSubmit}
        disabled={
          submitting ||
          submissionLocked
        }
      >
        <Send size={14} />

        {submitting
          ? "Submitting..."
          : submissionLocked
          ? "Work Submitted"
          : canResubmit
          ? "Resubmit Work"
          : "Submit Work"}
      </button>
    </div>
  );
}

/* =========================================================
   APPLICATIONS
========================================================= */

function ApplicationsTab() {
  const [applications, setApplications] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  const loadApplications =
    useCallback(async () => {
      try {
        setLoading(true);
        setError("");

        const data =
          await getMyApplications();

        setApplications(
          Array.isArray(data)
            ? data
            : []
        );
      } catch (err) {
        console.error(
          "Unable to load applications:",
          err
        );

        setError(
          err?.message ||
            "Unable to load applications."
        );
      } finally {
        setLoading(false);
      }
    }, []);

  useEffect(() => {
    loadApplications();
  }, [loadApplications]);

  if (loading) {
    return (
      <div className="dev-tab-empty">
        Loading applications...
      </div>
    );
  }

  if (error) {
    return (
      <div className="dev-tab-empty">
        <p>
          Unable to load applications.
        </p>

        <span>{error}</span>
      </div>
    );
  }

  if (!applications.length) {
    return (
      <div className="dev-tab-empty">
        <FileCheck
          size={34}
          style={{
            opacity: 0.3,
            marginBottom: 12,
          }}
        />

        <p>No applications yet.</p>

        <span>
          Your opportunity applications will appear here.
        </span>
      </div>
    );
  }

  return (
    <div className="dev-app-list">
      {applications.map(
        (application) => {
          const opportunity =
            application.opportunities ||
            application.opportunity ||
            null;

          return (
            <div
              key={application.id}
              className="dev-app-card"
            >
              <div>
                <span className="dev-opp-category">
                  {opportunity?.category ||
                    "Project"}
                </span>

                <h3>
                  {opportunity?.title ||
                    "Untitled Project"}
                </h3>

                <p>
                  Applied{" "}
                  {application.applied_at
                    ? new Date(
                        application.applied_at
                      ).toLocaleDateString(
                        "en-IN"
                      )
                    : "—"}
                </p>
              </div>

              <StatusBadge
                status={
                  application.status ||
                  "pending"
                }
              />
            </div>
          );
        }
      )}
    </div>
  );
}

/* =========================================================
   PROFILE
========================================================= */

function ProfileTab({
  profile,
  devProfile,
}) {
  const profileItems = [
    [
      "Full Name",
      profile?.full_name ||
        devProfile?.full_name,
    ],

    [
      "Email",
      profile?.email ||
        devProfile?.email,
    ],

    [
      "Phone",
      devProfile?.phone ||
        profile?.phone,
    ],

    [
      "City",
      devProfile?.city,
    ],

    [
      "GitHub",
      devProfile?.github_url,
    ],

    [
      "LinkedIn",
      devProfile?.linkedin_url,
    ],

    [
      "Portfolio",
      devProfile?.portfolio_url,
    ],

    [
      "Status",
      devProfile?.status,
    ],
  ];

  return (
    <div
      className="dev-auth-card"
      style={{
        padding: 28,
      }}
    >
      <h3>Your Profile</h3>

      <div className="admin-detail-grid">
        {profileItems.map(
          ([label, value]) => {
            const isLink =
              typeof value === "string" &&
              value.startsWith("http");

            return (
              <div
                key={label}
                className="admin-detail-item"
              >
                <span>{label}</span>

                {isLink ? (
                  <a
                    href={value}
                    target="_blank"
                    rel="noreferrer"
                  >
                    {value.replace(
                      /^https?:\/\//,
                      ""
                    )}

                    <ExternalLink size={10} />
                  </a>
                ) : (
                  <strong>
                    {value || "—"}
                  </strong>
                )}
              </div>
            );
          }
        )}
      </div>
    </div>
  );
}

/* =========================================================
   MAIN DASHBOARD
========================================================= */

export default function DevDashboard() {
  const {
    profile,
    devProfile,
    logout,
  } = useDeveloper();

  const [
    assignment,
    setAssignment,
  ] = useState(null);

  const [tab, setTab] =
    useState("opportunities");

  const [
    loadingAssignment,
    setLoadingAssignment,
  ] = useState(true);

  const [assignmentError, setAssignmentError] =
    useState("");

  /* =======================================================
     LOAD ASSIGNMENT
  ======================================================= */

  const loadAssignment =
    useCallback(async () => {
      try {
        setLoadingAssignment(true);
        setAssignmentError("");

        /*
         * IMPORTANT:
         *
         * getMyCurrentAssignment() gets the developer
         * from the authenticated Supabase user.
         *
         * Therefore we do NOT need to pass devProfile.id.
         */

        const data =
          await getMyCurrentAssignment();

        const currentAssignment =
          data || null;

        setAssignment(
          currentAssignment
        );

        /*
         * If an active project exists, show it.
         */

        if (currentAssignment) {
          setTab((currentTab) => {
            if (
              currentTab ===
                "opportunities" ||
              currentTab ===
                "applications"
            ) {
              return "project";
            }

            return currentTab;
          });
        } else {
          /*
           * No active project.
           */

          setTab((currentTab) => {
            if (
              currentTab === "project" ||
              currentTab === "submissions"
            ) {
              return "opportunities";
            }

            return currentTab;
          });
        }
      } catch (error) {
        console.error(
          "Unable to load current assignment:",
          error
        );

        setAssignment(null);

        setAssignmentError(
          error?.message ||
            "Unable to load your current project."
        );

        /*
         * Do NOT automatically kick the developer
         * to Opportunities on every error.
         *
         * That was making genuine database errors
         * look like there was simply no assignment.
         */
      } finally {
        setLoadingAssignment(false);
      }
    }, []);

  /* =======================================================
     INITIAL LOAD
  ======================================================= */

  useEffect(() => {
    if (!devProfile) {
      return;
    }

    loadAssignment();
  }, [devProfile, loadAssignment]);

  /* =======================================================
     AUTO REFRESH
  ======================================================= */

  useEffect(() => {
    if (!devProfile) {
      return undefined;
    }

    const interval =
      setInterval(() => {
        loadAssignment();
      }, 10000);

    return () => {
      clearInterval(interval);
    };
  }, [devProfile, loadAssignment]);

  /* =======================================================
     DISPLAY NAME
  ======================================================= */

  const displayName =
    profile?.full_name ||
    devProfile?.full_name ||
    "";

  const firstName =
    displayName
      ?.trim()
      .split(/\s+/)[0] || "";

  /* =======================================================
     ACTIVE PROJECT
  ======================================================= */

  const hasActiveProject =
    Boolean(assignment);

  /* =======================================================
     TABS
  ======================================================= */

  const tabs = hasActiveProject
    ? [
        {
          id: "project",
          label: "Current Project",
          icon: FolderKanban,
        },

        {
          id: "submissions",
          label: "Submit Work",
          icon: Send,
        },

        {
          id: "profile",
          label: "Profile",
          icon: User,
        },
      ]
    : [
        {
          id: "opportunities",
          label: "Opportunities",
          icon: Briefcase,
        },

        {
          id: "applications",
          label: "My Applications",
          icon: FileCheck,
        },

        {
          id: "profile",
          label: "Profile",
          icon: User,
        },
      ];

  /* =======================================================
     TAB RENDER
  ======================================================= */

  function renderTab() {
    if (loadingAssignment) {
      return (
        <div className="dev-tab-empty">
          Loading your developer dashboard...
        </div>
      );
    }

    /*
     * Show database/auth error instead of silently
     * displaying an empty dashboard.
     */

    if (
      assignmentError &&
      !assignment
    ) {
      return (
        <div className="dev-tab-empty">
          <FolderKanban
            size={34}
            style={{
              opacity: 0.3,
              marginBottom: 12,
            }}
          />

          <p>
            Unable to load dashboard data.
          </p>

          <span>
            {assignmentError}
          </span>

          <button
            type="button"
            className="primary-btn"
            style={{
              marginTop: 16,
            }}
            onClick={loadAssignment}
          >
            Try Again
          </button>
        </div>
      );
    }

    switch (tab) {
      case "project":
        return (
          <CurrentProjectTab
            assignment={assignment}
          />
        );

      case "submissions":
        return (
          <SubmitWorkTab
            assignment={assignment}
            onSubmitted={loadAssignment}
          />
        );

      case "opportunities":
        return (
          <OpportunitiesTab
            devProfile={devProfile}
            onAssignmentCreated={
              async () => {
                await loadAssignment();
                setTab("project");
              }
            }
          />
        );

      case "applications":
        return <ApplicationsTab />;

      case "profile":
        return (
          <ProfileTab
            profile={profile}
            devProfile={devProfile}
          />
        );

      default:
        return null;
    }
  }

  /* =======================================================
     RENDER
  ======================================================= */

  return (
    <div className="dev-dashboard-shell">

      {/* ===================================================
          TOPBAR
      =================================================== */}

      <header className="dev-dashboard-topbar">
        <div className="container dev-dashboard-topbar-inner">

          <div className="dev-dashboard-brand">
            <ExcwaLogo size={36} />

            <span>
              EXCWA{" "}
              <b>Developers</b>
            </span>
          </div>

          <div className="dev-dashboard-userbar">

            <span className="dev-dashboard-user-name">
              {displayName || "\u00A0"}
            </span>

            <button
              type="button"
              className="secondary-btn dev-signout-btn"
              onClick={logout}
            >
              <LogOut size={13} />

              Sign Out
            </button>

          </div>
        </div>
      </header>

      {/* ===================================================
          CONTENT
      =================================================== */}

      <div className="container dev-dashboard-content">

        {/* HERO */}

        <section className="dev-dashboard-hero">

          <div className="dev-dashboard-hero-copy">

            <p className="eyebrow">
              Developer Portal
            </p>

            <h1>
              Welcome back,{" "}
              <span>
                {firstName || "\u00A0"}
              </span>
            </h1>

            <p>
              {hasActiveProject
                ? "Your current project is assigned and ready to work on."
                : "Browse available projects and find your next opportunity."}
            </p>

          </div>

          <div className="dev-dashboard-hero-metrics">

            <div className="dev-metric-card">
              <span className="dev-metric-label">
                Status
              </span>

              <strong>
                {devProfile?.status ||
                  "pending"}
              </strong>
            </div>

            <div className="dev-metric-card">
              <span className="dev-metric-label">
                Project
              </span>

              <strong>
                {hasActiveProject
                  ? "Assigned"
                  : "Available"}
              </strong>
            </div>

          </div>
        </section>

        {/* TABS */}

        <div className="dev-tabs">
          {tabs.map(
            ({
              id,
              label,
              icon: Icon,
            }) => (
              <button
                key={id}
                type="button"
                className={`dev-tab ${
                  tab === id
                    ? "active"
                    : ""
                }`}
                onClick={() =>
                  setTab(id)
                }
              >
                <Icon size={14} />

                {label}
              </button>
            )
          )}
        </div>

        {/* PANEL */}

        <div className="dev-dashboard-panel">
          {renderTab()}
        </div>

      </div>
    </div>
  );
}