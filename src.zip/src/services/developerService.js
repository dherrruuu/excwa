import { supabase } from "../lib/supabase";

import {
  submitProject,
  getMySubmission,
  getMySubmissions as getDeveloperSubmissions,
  uploadProjectZip,
} from "./developer/developerSubmissionService";

/*
============================================================
EXCWA DEVELOPER SERVICE
============================================================

Responsibilities:
- Authentication
- Developer profile
- Skills
- Opportunities
- Applications
- Current assignments
- Developer workload
- Admin developer management
- Admin opportunity management
- Submission/review management

IMPORTANT
------------------------------------------------------------
developer_profiles DOES NOT contain an email column.

Developer email comes from:
    auth.users.email

Developer information comes from:
    developer_profiles

Therefore we NEVER request:

    developer_profiles.email

The email is attached to the developer object in JavaScript.
============================================================
*/


/* ==========================================================
   AUTH HELPERS
========================================================== */

async function getCurrentUser() {
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error) {
    throw error;
  }

  if (!user) {
    throw new Error("You must be signed in.");
  }

  return user;
}


/* ==========================================================
   CURRENT DEVELOPER PROFILE
========================================================== */

async function getCurrentDeveloperProfile() {
  const user = await getCurrentUser();

  /*
   * IMPORTANT:
   *
   * DO NOT add email here.
   *
   * developer_profiles does not have an email column.
   */

  const {
    data,
    error,
  } = await supabase
    .from("developer_profiles")
    .select(`
      id,
      user_id,
      full_name,
      phone,
      city,
      github_url,
      linkedin_url,
      portfolio_url,
      status,
      rejection_reason,
      primary_roles,
      created_at,
      updated_at
    `)
    .eq("user_id", user.id)
    .maybeSingle();

  if (error) {
    console.error(
      "Developer profile query failed:",
      error
    );

    throw error;
  }

  if (!data) {
    throw new Error(
      "Developer profile not found for the current user."
    );
  }

  /*
   * Email comes from auth.users.
   *
   * We attach it to the returned JavaScript object.
   *
   * This does NOT require an email column in
   * developer_profiles.
   */

  return {
    ...data,
    email: user.email || null,
  };
}


/* ==========================================================
   ROLE HELPERS
========================================================== */

async function getCurrentUserRole() {
  const user = await getCurrentUser();

  const {
    data,
    error,
  } = await supabase
    .from("user_profiles")
    .select("role")
    .eq("id", user.id)
    .maybeSingle();

  if (error) {
    throw error;
  }

  return data?.role || null;
}


async function requireAdmin() {
  const role = await getCurrentUserRole();

  if (role !== "admin") {
    throw new Error(
      "You are not authorized to perform this action."
    );
  }
}


async function requireAdminOrReviewer() {
  const role = await getCurrentUserRole();

  if (
    !["admin", "reviewer"].includes(role)
  ) {
    throw new Error(
      "You are not authorized to perform this action."
    );
  }

  return role;
}


/* ==========================================================
   REGISTRATION
========================================================== */

export async function registerDeveloper({
  full_name,
  email,
  password,
}) {
  const {
    data: authData,
    error: authError,
  } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        full_name,
      },
    },
  });

  if (authError) {
    throw authError;
  }

  return {
    user: authData?.user || null,
    emailConfirmationRequired:
      !authData?.session,
  };
}


/* ==========================================================
   SKILLS
========================================================== */

export async function getAllSkills() {
  const {
    data,
    error,
  } = await supabase
    .from("skills")
    .select("*")
    .order("name", {
      ascending: true,
    });

  if (error) {
    throw error;
  }

  return data || [];
}


/* ==========================================================
   ACTIVE ASSIGNMENT CHECK
========================================================== */

export async function hasActiveAssignment() {
  const developer =
    await getCurrentDeveloperProfile();

  const {
    data,
    error,
  } = await supabase
    .from("project_assignments")
    .select(`
      id,
      opportunity_id,
      status,
      completed_at
    `)
    .eq(
      "developer_id",
      developer.id
    )
    .is(
      "completed_at",
      null
    )
    .limit(1)
    .maybeSingle();

  if (error) {
    throw error;
  }

  return Boolean(data);
}


/* ==========================================================
   OPEN OPPORTUNITIES
========================================================== */

export async function getOpenOpportunities() {
  const developer =
    await getCurrentDeveloperProfile();

  /*
   * Only approved developers can see opportunities.
   */

  if (
    developer.status !== "approved"
  ) {
    return [];
  }

  /*
   * Check whether developer already has
   * an active project.
   */

  const {
    data: activeAssignment,
    error: assignmentError,
  } = await supabase
    .from("project_assignments")
    .select(`
      id,
      opportunity_id,
      status,
      completed_at
    `)
    .eq(
      "developer_id",
      developer.id
    )
    .is(
      "completed_at",
      null
    )
    .limit(1)
    .maybeSingle();

  if (assignmentError) {
    throw assignmentError;
  }

  /*
   * Developer is busy.
   */

  if (activeAssignment) {
    return [];
  }

  /*
   * Developer is available.
   */

  const {
    data,
    error,
  } = await supabase
    .from("opportunities")
    .select(`
      id,
      title,
      description,
      category,
      project_type,
      required_roles,
      required_skills,
      tech_stack,
      deliverables,
      deadline,
      application_deadline,
      budget,
      freelancer_payout,
      attachment_path,
      status,
      created_at
    `)
    .eq(
      "status",
      "open"
    )
    .order(
      "created_at",
      {
        ascending: false,
      }
    );

  if (error) {
    console.error(
      "Open opportunities query failed:",
      error
    );

    throw error;
  }

  return data || [];
}


/* ==========================================================
   APPLY TO OPPORTUNITY
========================================================== */

export async function applyToOpportunity({
  opportunityId,
  coverMessage,
  estimatedDays,
}) {
  if (!opportunityId) {
    throw new Error(
      "Opportunity ID is required."
    );
  }

  const developer =
    await getCurrentDeveloperProfile();

  /*
   * Developer must be approved.
   */

  if (
    developer.status !== "approved"
  ) {
    throw new Error(
      "Your developer account is not approved."
    );
  }

  /*
   * --------------------------------------------------------
   * CHECK ACTIVE ASSIGNMENT
   * --------------------------------------------------------
   */

  const {
    data: activeAssignment,
    error: activeAssignmentError,
  } = await supabase
    .from("project_assignments")
    .select(`
      id,
      opportunity_id,
      status,
      completed_at
    `)
    .eq(
      "developer_id",
      developer.id
    )
    .is(
      "completed_at",
      null
    )
    .limit(1)
    .maybeSingle();

  if (activeAssignmentError) {
    throw activeAssignmentError;
  }

  if (activeAssignment) {
    throw new Error(
      "You already have an active project. Complete it before applying for another opportunity."
    );
  }

  /*
   * --------------------------------------------------------
   * GET OPPORTUNITY
   * --------------------------------------------------------
   */

  const {
    data: opportunity,
    error: opportunityError,
  } = await supabase
    .from("opportunities")
    .select(`
      id,
      title,
      status,
      application_deadline
    `)
    .eq(
      "id",
      opportunityId
    )
    .maybeSingle();

  if (opportunityError) {
    throw opportunityError;
  }

  if (!opportunity) {
    throw new Error(
      "Opportunity not found."
    );
  }

  /*
   * Only open opportunities.
   */

  if (
    opportunity.status !== "open"
  ) {
    throw new Error(
      "This opportunity is no longer available."
    );
  }

  /*
   * --------------------------------------------------------
   * APPLICATION DEADLINE
   * --------------------------------------------------------
   */

  if (
    opportunity.application_deadline
  ) {
    const deadline =
      new Date(
        opportunity.application_deadline
      );

    if (
      !Number.isNaN(
        deadline.getTime()
      ) &&
      deadline.getTime() <
        Date.now()
    ) {
      throw new Error(
        "The application deadline for this opportunity has passed."
      );
    }
  }

  /*
   * --------------------------------------------------------
   * DUPLICATE APPLICATION CHECK
   * --------------------------------------------------------
   */

  const {
    data: existingApplication,
    error: existingApplicationError,
  } = await supabase
    .from("opportunity_applications")
    .select(`
      id,
      status
    `)
    .eq(
      "opportunity_id",
      opportunityId
    )
    .eq(
      "developer_id",
      developer.id
    )
    .maybeSingle();

  if (existingApplicationError) {
    throw existingApplicationError;
  }

  if (existingApplication) {
    throw new Error(
      "You have already applied for this opportunity."
    );
  }

  /*
   * --------------------------------------------------------
   * CREATE APPLICATION
   * --------------------------------------------------------
   *
   * The browser creates ONLY the application.
   *
   * It does not create project_assignments.
   */

  const {
    data: application,
    error: applicationError,
  } = await supabase
    .from("opportunity_applications")
    .insert({
      opportunity_id:
        opportunityId,

      developer_id:
        developer.id,

      cover_message:
        coverMessage?.trim() ||
        null,

      estimated_days:
        estimatedDays
          ? Number(
              estimatedDays
            )
          : null,

      status: "approved",
    })
    .select()
    .single();

  if (applicationError) {
    console.error(
      "Application creation failed:",
      applicationError
    );

    throw applicationError;
  }

  /*
   * --------------------------------------------------------
   * FIND DATABASE CREATED ASSIGNMENT
   * --------------------------------------------------------
   */

  const {
    data: assignment,
    error: assignmentError,
  } = await supabase
    .from("project_assignments")
    .select("*")
    .eq(
      "opportunity_id",
      opportunityId
    )
    .eq(
      "developer_id",
      developer.id
    )
    .order(
      "assigned_at",
      {
        ascending: false,
      }
    )
    .limit(1)
    .maybeSingle();

  if (assignmentError) {
    throw assignmentError;
  }

  return {
    application,
    assignment:
      assignment || null,
  };
}


/* ==========================================================
   MY APPLICATIONS
========================================================== */

export async function getMyApplications() {
  const developer =
    await getCurrentDeveloperProfile();

  const {
    data,
    error,
  } = await supabase
    .from("opportunity_applications")
    .select(`
      id,
      opportunity_id,
      developer_id,
      cover_message,
      estimated_days,
      status,
      applied_at,
      reviewed_at,

      opportunities (
        id,
        title,
        category,
        project_type,
        tech_stack,
        budget,
        freelancer_payout,
        deadline,
        status
      )
    `)
    .eq(
      "developer_id",
      developer.id
    )
    .order(
      "applied_at",
      {
        ascending: false,
      }
    );

  if (error) {
    console.error(
      "Applications query failed:",
      error
    );

    throw error;
  }

  return data || [];
}


/* ==========================================================
   CURRENT ASSIGNMENT
========================================================== */

export async function getMyCurrentAssignment() {
  const developer =
    await getCurrentDeveloperProfile();

  const {
    data,
    error,
  } = await supabase
    .from("project_assignments")
    .select(`
      *,
      opportunities (
        id,
        title,
        description,
        category,
        project_type,
        required_roles,
        required_skills,
        tech_stack,
        deliverables,
        deadline,
        application_deadline,
        budget,
        freelancer_payout,
        attachment_path,
        status
      ),
      project_submissions (
        id,
        github_url,
        zip_path,
        submission_notes,
        status,
        submitted_at,
        review_message,
        reviewed_at,
        reviewed_by
      )
    `)
    .eq("developer_id", developer.id)
    .is("completed_at", null)
    .order("assigned_at", {
      ascending: false,
    })
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error(
      "getMyCurrentAssignment error:",
      error
    );

    throw error;
  }

  return data || null;
}


/* ==========================================================
   SUBMISSION COMPATIBILITY
========================================================== */

export async function submitWork({
  assignmentId,
  githubUrl,
  notes,
  zipPath = null,
}) {
  if (!assignmentId) {
    throw new Error(
      "Assignment ID is required."
    );
  }

  return submitProject({
    assignmentId,
    githubUrl,
    submissionNotes:
      notes,
    zipPath,
  });
}


export { getMySubmission };


export async function getMySubmissions() {
  return getDeveloperSubmissions();
}


export { uploadProjectZip };


/* ==========================================================
   ADMIN: GET DEVELOPERS
========================================================== */

export async function getAllDevelopers() {
  await requireAdmin();

  const {
    data,
    error,
  } = await supabase
    .from("developer_profiles")
    .select(`
      id,
      user_id,
      full_name,
      phone,
      city,
      github_url,
      linkedin_url,
      portfolio_url,
      status,
      rejection_reason,
      primary_roles,
      created_at,
      updated_at,

      developer_skills (
        skills (
          id,
          name
        )
      )
    `)
    .order(
      "created_at",
      {
        ascending: false,
      }
    );

  if (error) {
    throw error;
  }

  /*
   * Email is NOT queried from developer_profiles.
   *
   * If admin needs email, we can separately obtain it
   * through user_profiles/auth depending on your schema.
   */

  return data || [];
}


/* ==========================================================
   ADMIN: DEVELOPER WORKLOAD
========================================================== */

export async function getDeveloperWorkload(
  developerId
) {
  await requireAdmin();

  if (!developerId) {
    throw new Error(
      "Developer ID is required."
    );
  }

  const {
    data: developer,
    error: developerError,
  } = await supabase
    .from("developer_profiles")
    .select(`
      id,
      user_id,
      full_name,
      phone,
      city,
      github_url,
      linkedin_url,
      portfolio_url,
      status,
      rejection_reason,
      primary_roles,

      developer_skills (
        skills (
          id,
          name
        )
      )
    `)
    .eq(
      "id",
      developerId
    )
    .maybeSingle();

  if (developerError) {
    throw developerError;
  }

  if (!developer) {
    throw new Error(
      "Developer not found."
    );
  }

  const {
    data: assignments,
    error: assignmentError,
  } = await supabase
    .from("project_assignments")
    .select(`
      *,

      opportunities (
        id,
        title,
        category,
        status,
        deadline,
        freelancer_payout
      ),

      project_submissions (
        id,
        status,
        submitted_at,
        reviewed_at,
        review_message
      )
    `)
    .eq(
      "developer_id",
      developerId
    )
    .order(
      "assigned_at",
      {
        ascending: false,
      }
    );

  if (assignmentError) {
    throw assignmentError;
  }

  const allAssignments =
    assignments || [];

  const currentProjects =
    allAssignments.filter(
      (assignment) =>
        !assignment.completed_at
    );

  const completedProjects =
    allAssignments.filter(
      (assignment) =>
        Boolean(
          assignment.completed_at
        )
    );

  return {
    developer,

    totalProjects:
      allAssignments.length,

    completedProjects:
      completedProjects.length,

    currentProjects:
      currentProjects.length,

    isBusy:
      currentProjects.length >
      0,

    isAvailable:
      currentProjects.length ===
      0,

    hasWorked:
      allAssignments.length >
      0,

    assignments:
      allAssignments,
  };
}


/* ==========================================================
   ADMIN: ALL DEVELOPER WORKLOADS
========================================================== */

export async function getAllDeveloperWorkloads() {
  await requireAdmin();

  const developers =
    await getAllDevelopers();

  const {
    data: assignments,
    error,
  } = await supabase
    .from("project_assignments")
    .select(`
      id,
      developer_id,
      opportunity_id,
      status,
      assigned_at,
      started_at,
      completed_at,
      payment_status,

      opportunities (
        id,
        title,
        category,
        status
      )
    `)
    .order(
      "assigned_at",
      {
        ascending: false,
      }
    );

  if (error) {
    throw error;
  }

  const assignmentList =
    assignments || [];

  return developers.map(
    (developer) => {
      const developerAssignments =
        assignmentList.filter(
          (assignment) =>
            assignment.developer_id ===
            developer.id
        );

      const currentProjects =
        developerAssignments.filter(
          (assignment) =>
            !assignment.completed_at
        );

      const completedProjects =
        developerAssignments.filter(
          (assignment) =>
            Boolean(
              assignment.completed_at
            )
        );

      return {
        ...developer,

        totalProjects:
          developerAssignments.length,

        completedProjects:
          completedProjects.length,

        currentProjects:
          currentProjects.length,

        isBusy:
          currentProjects.length >
          0,

        isAvailable:
          currentProjects.length ===
          0,

        hasWorked:
          developerAssignments.length >
          0,

        assignments:
          developerAssignments,
      };
    }
  );
}


/* ==========================================================
   ADMIN: UPDATE DEVELOPER STATUS
========================================================== */

export async function updateDeveloperStatus(
  devProfileId,
  status,
  rejectionReason = null
) {
  await requireAdmin();

  const allowedStatuses = [
    "pending",
    "approved",
    "rejected",
  ];

  if (
    !allowedStatuses.includes(
      status
    )
  ) {
    throw new Error(
      "Invalid developer status."
    );
  }

  const {
    data,
    error,
  } = await supabase
    .from("developer_profiles")
    .update({
      status,

      rejection_reason:
        status === "rejected"
          ? rejectionReason
              ?.trim() || null
          : null,
    })
    .eq(
      "id",
      devProfileId
    )
    .select()
    .single();

  if (error) {
    throw error;
  }

  return data;
}


/* ==========================================================
   ADMIN: REMOVE UNUSED DEVELOPER
========================================================== */

export async function removeUnusedDeveloper(
  developerId
) {
  await requireAdmin();

  if (!developerId) {
    throw new Error(
      "Developer ID is required."
    );
  }

  const {
    count,
    error: assignmentError,
  } = await supabase
    .from("project_assignments")
    .select("id", {
      count: "exact",
      head: true,
    })
    .eq(
      "developer_id",
      developerId
    );

  if (assignmentError) {
    throw assignmentError;
  }

  if ((count || 0) > 0) {
    throw new Error(
      "This developer has project history and cannot be removed from this section."
    );
  }

  const {
    count: applicationCount,
    error: applicationError,
  } = await supabase
    .from("opportunity_applications")
    .select("id", {
      count: "exact",
      head: true,
    })
    .eq(
      "developer_id",
      developerId
    );

  if (applicationError) {
    throw applicationError;
  }

  if (
    (applicationCount || 0) >
    0
  ) {
    throw new Error(
      "This developer has application history and cannot be removed from this section."
    );
  }

  const {
    error: skillsError,
  } = await supabase
    .from("developer_skills")
    .delete()
    .eq(
      "developer_id",
      developerId
    );

  if (skillsError) {
    throw skillsError;
  }

  const {
    data,
    error,
  } = await supabase
    .from("developer_profiles")
    .delete()
    .eq(
      "id",
      developerId
    )
    .select()
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (!data) {
    throw new Error(
      "Developer could not be removed."
    );
  }

  return data;
}


/* ==========================================================
   ADMIN: ALL OPPORTUNITIES
========================================================== */

export async function getAllOpportunities() {
  await requireAdmin();

  const {
    data,
    error,
  } = await supabase
    .from("opportunities")
    .select("*")
    .order(
      "created_at",
      {
        ascending: false,
      }
    );

  if (error) {
    throw error;
  }

  return data || [];
}


/* ==========================================================
   ADMIN: CREATE OPPORTUNITY
========================================================== */

export async function createOpportunity(
  payload
) {
  await requireAdmin();

  const {
    data,
    error,
  } = await supabase
    .from("opportunities")
    .insert(payload)
    .select()
    .single();

  if (error) {
    throw error;
  }

  return data;
}


/* ==========================================================
   ADMIN: UPDATE OPPORTUNITY
========================================================== */

export async function updateOpportunity(
  id,
  payload
) {
  await requireAdmin();

  const {
    data,
    error,
  } = await supabase
    .from("opportunities")
    .update(payload)
    .eq(
      "id",
      id
    )
    .select()
    .single();

  if (error) {
    throw error;
  }

  return data;
}


/* ==========================================================
   ADMIN: DELETE OPPORTUNITY
========================================================== */

export async function deleteOpportunity(
  opportunityId
) {
  await requireAdmin();

  if (!opportunityId) {
    throw new Error(
      "Opportunity ID is required."
    );
  }

  const {
    count: assignmentCount,
    error: assignmentError,
  } = await supabase
    .from("project_assignments")
    .select("id", {
      count: "exact",
      head: true,
    })
    .eq(
      "opportunity_id",
      opportunityId
    );

  if (assignmentError) {
    throw assignmentError;
  }

  if (
    (assignmentCount || 0) >
    0
  ) {
    throw new Error(
      "This opportunity has project history and cannot be deleted."
    );
  }

  const {
    error: applicationsError,
  } = await supabase
    .from("opportunity_applications")
    .delete()
    .eq(
      "opportunity_id",
      opportunityId
    );

  if (applicationsError) {
    throw applicationsError;
  }

  const {
    data,
    error,
  } = await supabase
    .from("opportunities")
    .delete()
    .eq(
      "id",
      opportunityId
    )
    .select()
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (!data) {
    throw new Error(
      "Opportunity not found or could not be deleted."
    );
  }

  return data;
}


/* ==========================================================
   ADMIN: APPLICATIONS
========================================================== */

export async function getOpportunityApplications(
  opportunityId
) {
  await requireAdmin();

  if (!opportunityId) {
    throw new Error(
      "Opportunity ID is required."
    );
  }

  const {
    data,
    error,
  } = await supabase
    .from("opportunity_applications")
    .select(`
      id,
      opportunity_id,
      developer_id,
      cover_message,
      estimated_days,
      status,
      applied_at,
      reviewed_at,

      developer_profiles (
        id,
        user_id,
        full_name,
        city,
        primary_roles,
        github_url,
        linkedin_url,
        portfolio_url,
        status,

        developer_skills (
          skills (
            id,
            name
          )
        )
      )
    `)
    .eq(
      "opportunity_id",
      opportunityId
    )
    .order(
      "applied_at",
      {
        ascending: false,
      }
    );

  if (error) {
    console.error(
      "Opportunity applications query failed:",
      error
    );

    throw error;
  }

  return data || [];
}


/* ==========================================================
   ADMIN: ALL ASSIGNMENTS
========================================================== */

export async function getAllAssignments() {
  await requireAdmin();

  const {
    data,
    error,
  } = await supabase
    .from("project_assignments")
    .select(`
      *,

      opportunities (
        id,
        title,
        category,
        freelancer_payout
      ),

      developer_profiles (
        id,
        user_id,
        full_name,
        city
      ),

      project_submissions (
        id,
        github_url,
        zip_path,
        submission_notes,
        status,
        submitted_at,
        review_message,
        reviewed_at
      )
    `)
    .order(
      "assigned_at",
      {
        ascending: false,
      }
    );

  if (error) {
    throw error;
  }

  return data || [];
}


/* ==========================================================
   ADMIN / REVIEWER: REVIEW SUBMISSION
========================================================== */

export async function reviewSubmission({
  submissionId,
  status,
  reviewMessage,
}) {
  const reviewerRole =
    await requireAdminOrReviewer();

  const allowedStatuses = [
    "completed",
    "rejected",
    "changes_requested",
  ];

  if (
    !allowedStatuses.includes(
      status
    )
  ) {
    throw new Error(
      "Invalid submission status."
    );
  }

  const user =
    await getCurrentUser();

  /*
   * --------------------------------------------------------
   * GET SUBMISSION
   * --------------------------------------------------------
   */

  const {
    data: submission,
    error: submissionError,
  } = await supabase
    .from("project_submissions")
    .select(`
      id,
      assignment_id,
      developer_id,
      status,

      project_assignments (
        id,
        opportunity_id,
        developer_id,
        completed_at
      )
    `)
    .eq(
      "id",
      submissionId
    )
    .maybeSingle();

  if (submissionError) {
    throw submissionError;
  }

  if (!submission) {
    throw new Error(
      "Submission not found."
    );
  }

  const assignment =
    submission.project_assignments;

  if (!assignment) {
    throw new Error(
      "Assignment not found."
    );
  }

  if (
    assignment.completed_at
  ) {
    throw new Error(
      "This project has already been completed."
    );
  }

  /*
   * --------------------------------------------------------
   * UPDATE SUBMISSION
   * --------------------------------------------------------
   */

  const {
    data,
    error,
  } = await supabase
    .from("project_submissions")
    .update({
      status,

      review_message:
        reviewMessage
          ?.trim() || null,

      reviewed_at:
        new Date().toISOString(),

      reviewed_by:
        user.id,
    })
    .eq(
      "id",
      submissionId
    )
    .select()
    .single();

  if (error) {
    throw error;
  }

  /*
   * --------------------------------------------------------
   * COMPLETED
   * --------------------------------------------------------
   */

  if (
    status === "completed"
  ) {
    const completedAt =
      new Date().toISOString();

    const {
      error: assignmentError,
    } = await supabase
      .from("project_assignments")
      .update({
        status:
          "completed",

        completed_at:
          completedAt,

        payment_status:
          "partially_paid",

        updated_at:
          completedAt,
      })
      .eq(
        "id",
        assignment.id
      );

    if (assignmentError) {
      throw assignmentError;
    }

    /*
     * Opportunity becomes completed.
     */

    const {
      error: opportunityError,
    } = await supabase
      .from("opportunities")
      .update({
        status:
          "completed",
      })
      .eq(
        "id",
        assignment.opportunity_id
      );

    if (opportunityError) {
      throw opportunityError;
    }
  }

  /*
   * --------------------------------------------------------
   * CHANGES REQUESTED
   * --------------------------------------------------------
   */

  if (
    status ===
    "changes_requested"
  ) {
    const {
      error: assignmentError,
    } = await supabase
      .from("project_assignments")
      .update({
        status:
          "in_progress",

        updated_at:
          new Date().toISOString(),
      })
      .eq(
        "id",
        assignment.id
      );

    if (assignmentError) {
      throw assignmentError;
    }
  }

  /*
   * --------------------------------------------------------
   * REJECTED
   * --------------------------------------------------------
   */

  if (
    status === "rejected"
  ) {
    const {
      error: assignmentError,
    } = await supabase
      .from("project_assignments")
      .update({
        status:
          "in_progress",

        updated_at:
          new Date().toISOString(),
      })
      .eq(
        "id",
        assignment.id
      );

    if (assignmentError) {
      throw assignmentError;
    }
  }

  return {
    submission: data,
    reviewerRole,
  };
}


/* ==========================================================
   ADMIN: DELETE REVIEW / SUBMISSION
========================================================== */

export async function deleteSubmission(
  submissionId
) {
  await requireAdmin();

  if (!submissionId) {
    throw new Error(
      "Submission ID is required."
    );
  }

  const {
    data: submission,
    error: submissionError,
  } = await supabase
    .from("project_submissions")
    .select(`
      id,
      assignment_id,
      status,

      project_assignments (
        id,
        completed_at
      )
    `)
    .eq(
      "id",
      submissionId
    )
    .maybeSingle();

  if (submissionError) {
    throw submissionError;
  }

  if (!submission) {
    throw new Error(
      "Review not found."
    );
  }

  const {
    data,
    error,
  } = await supabase
    .from("project_submissions")
    .delete()
    .eq(
      "id",
      submissionId
    )
    .select()
    .maybeSingle();

  if (error) {
    throw error;
  }

  if (!data) {
    throw new Error(
      "Review could not be deleted."
    );
  }

  return data;
}


/* ==========================================================
   DATABASE DEBUG
========================================================== */

export async function debugDatabaseConnection() {
  console.log(
    "================================================"
  );

  console.log(
    "EXCWA DATABASE CONNECTION DEBUG"
  );

  console.log(
    "================================================"
  );

  /*
   * --------------------------------------------------------
   * AUTH SESSION
   * --------------------------------------------------------
   */

  const {
    data: sessionData,
    error: sessionError,
  } = await supabase.auth.getSession();

  console.log(
    "AUTH SESSION:",
    sessionData
  );

  console.log(
    "AUTH ERROR:",
    sessionError
  );

  /*
   * --------------------------------------------------------
   * CURRENT USER
   * --------------------------------------------------------
   */

  const {
    data: userData,
    error: userError,
  } = await supabase.auth.getUser();

  console.log(
    "CURRENT USER:",
    userData?.user ||
      null
  );

  console.log(
    "CURRENT USER ERROR:",
    userError
  );

  /*
   * --------------------------------------------------------
   * CURRENT DEVELOPER
   * --------------------------------------------------------
   */

  let developer =
    null;

  if (
    userData?.user
  ) {
    const {
      data,
      error,
    } = await supabase
      .from("developer_profiles")
      .select(`
        id,
        user_id,
        full_name,
        phone,
        city,
        github_url,
        linkedin_url,
        portfolio_url,
        status,
        rejection_reason,
        primary_roles
      `)
      .eq(
        "user_id",
        userData.user.id
      )
      .maybeSingle();

    developer = data
      ? {
          ...data,
          email:
            userData.user
              .email ||
            null,
        }
      : null;

    console.log(
      "DEVELOPER PROFILE:",
      developer
    );

    console.log(
      "DEVELOPER PROFILE ERROR:",
      error
    );
  }

  /*
   * --------------------------------------------------------
   * OPPORTUNITIES
   * --------------------------------------------------------
   */

  const {
    data: opportunities,
    error: opportunitiesError,
  } = await supabase
    .from("opportunities")
    .select(`
      id,
      title,
      status,
      created_at
    `)
    .order(
      "created_at",
      {
        ascending: false,
      }
    );

  console.log(
    "OPPORTUNITIES:",
    opportunities
  );

  console.log(
    "OPPORTUNITIES ERROR:",
    opportunitiesError
  );

  /*
   * --------------------------------------------------------
   * PROJECT ASSIGNMENTS
   * --------------------------------------------------------
   */

  const {
    data: assignments,
    error: assignmentsError,
  } = await supabase
    .from("project_assignments")
    .select(`
      id,
      opportunity_id,
      developer_id,
      assigned_by,
      status,
      assigned_at,
      started_at,
      completed_at,
      payment_status
    `)
    .order(
      "assigned_at",
      {
        ascending: false,
      }
    );

  console.log(
    "PROJECT ASSIGNMENTS:",
    assignments
  );

  console.log(
    "PROJECT ASSIGNMENTS ERROR:",
    assignmentsError
  );

  /*
   * --------------------------------------------------------
   * CURRENT DEVELOPER ASSIGNMENTS
   * --------------------------------------------------------
   */

  let developerAssignments =
    [];

  if (
    developer?.id
  ) {
    const {
      data,
      error,
    } = await supabase
      .from("project_assignments")
      .select(`
        id,
        opportunity_id,
        developer_id,
        status,
        assigned_at,
        completed_at,
        payment_status
      `)
      .eq(
        "developer_id",
        developer.id
      )
      .order(
        "assigned_at",
        {
          ascending: false,
        }
      );

    developerAssignments =
      data || [];

    console.log(
      "CURRENT DEVELOPER ASSIGNMENTS:",
      data
    );

    console.log(
      "CURRENT DEVELOPER ASSIGNMENTS ERROR:",
      error
    );
  }

  /*
   * --------------------------------------------------------
   * ACTIVE ASSIGNMENT
   * --------------------------------------------------------
   */

  let activeAssignment =
    null;

  if (
    developer?.id
  ) {
    const {
      data,
      error,
    } = await supabase
      .from("project_assignments")
      .select(`
        id,
        opportunity_id,
        status,
        completed_at
      `)
      .eq(
        "developer_id",
        developer.id
      )
      .is(
        "completed_at",
        null
      )
      .limit(1)
      .maybeSingle();

    activeAssignment =
      data || null;

    console.log(
      "ACTIVE ASSIGNMENT:",
      data
    );

    console.log(
      "ACTIVE ASSIGNMENT ERROR:",
      error
    );
  }

  /*
   * --------------------------------------------------------
   * OPEN OPPORTUNITIES
   * --------------------------------------------------------
   */

  const {
    data: openOpportunities,
    error: openOpportunitiesError,
  } = await supabase
    .from("opportunities")
    .select(`
      id,
      title,
      status
    `)
    .eq(
      "status",
      "open"
    )
    .order(
      "created_at",
      {
        ascending: false,
      }
    );

  console.log(
    "OPEN OPPORTUNITIES:",
    openOpportunities
  );

  console.log(
    "OPEN OPPORTUNITIES ERROR:",
    openOpportunitiesError
  );

  /*
   * --------------------------------------------------------
   * FINAL RESULT
   * --------------------------------------------------------
   */

  const result = {
    session:
      sessionData,

    sessionError,

    user:
      userData?.user ||
      null,

    userError,

    developer,

    opportunities,

    opportunitiesError,

    assignments,

    assignmentsError,

    developerAssignments,

    activeAssignment,

    openOpportunities,

    openOpportunitiesError,
  };

  console.log(
    "FINAL DATABASE DEBUG RESULT:",
    result
  );

  console.log(
    "================================================"
  );

  return result;
}